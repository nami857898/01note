package com.example.note01;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final String[] months = {"Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"};
    private final String[] defaultTabs = {"Not 1","Not 2","Not 3","Not 4","Not 5","Not 6"};
    private final int orange = Color.rgb(230, 74, 25), bg = Color.rgb(48, 34, 32), panel = Color.rgb(22, 22, 22);
    private int month = Calendar.getInstance().get(Calendar.MONTH);
    private int year = Calendar.getInstance().get(Calendar.YEAR);
    private String activeTab = "Not 3";
    private LinearLayout root, monthRow, tabRow, notesArea;
    private EditText editor;
    private TextView title;
    private JSONObject data;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        data = loadData();
        getWindow().setStatusBarColor(Color.rgb(28,22,22));
        getWindow().setNavigationBarColor(Color.rgb(28,22,22));
        buildUi();
    }

    private JSONObject loadData() {
        String raw = getSharedPreferences("agenda", MODE_PRIVATE).getString("data", "{}");
        try { return new JSONObject(raw); } catch(Exception e) { return new JSONObject(); }
    }
    private String key() { return year + "-" + (month+1); }
    private JSONObject monthData() {
        JSONObject obj = data.optJSONObject(key());
        if (obj == null) { obj = new JSONObject(); try { data.put(key(), obj); } catch(Exception ignored){} }
        return obj;
    }
    private String readNote(String tab) { return monthData().optString(tab, ""); }
    private void saveNote(String tab, String text) {
        try {
            monthData().put(tab, text);
            monthData().put(tab + "__updated", new SimpleDateFormat("dd.MM.yyyy - HH:mm", new Locale("tr","TR")).format(new Date()));
            getSharedPreferences("agenda", MODE_PRIVATE).edit().putString("data", data.toString()).apply();
        } catch(Exception ignored) {}
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(22)); root.setBackgroundColor(bg);
        scroll.addView(root); setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        title = text("", 25, orange, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(54), 1f));
        Button allNotes = button("Tüm Notlar", panel, Color.WHITE);
        allNotes.setTextSize(14);
        header.addView(allNotes, lp(-2, dp(44)));
        allNotes.setOnClickListener(v -> showAllNotes());
        root.addView(header, lp(-1, dp(54)));
        monthRow = new LinearLayout(this); monthRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView mscroll = new HorizontalScrollView(this); mscroll.setHorizontalScrollBarEnabled(false); mscroll.addView(monthRow);
        root.addView(mscroll, lp(-1, dp(54)));
        for(int i=0;i<12;i++) {
            final int idx=i; Button b=button(months[i], i==month?orange:panel, Color.WHITE);
            monthRow.addView(b, new LinearLayout.LayoutParams(dp(105), dp(46)));
            b.setOnClickListener(v->{ saveCurrentEditor(); month=idx; refresh(); });
        }

        tabRow = new LinearLayout(this); tabRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView tscroll = new HorizontalScrollView(this); tscroll.setHorizontalScrollBarEnabled(false); tscroll.addView(tabRow);
        LinearLayout.LayoutParams tparams=lp(-1, dp(58)); tparams.topMargin=dp(12); root.addView(tscroll,tparams);

        TextView historyHead=text("Düzenleme Geçmişi (Tarih ve Saat):",16,orange,true);
        LinearLayout history = new LinearLayout(this); history.setOrientation(LinearLayout.VERTICAL); history.setPadding(dp(14),dp(12),dp(14),dp(12)); history.setBackground(round(panel,dp(10)));
        history.addView(historyHead);
        TextView historyText=text("",14,Color.WHITE,false); historyText.setTag("history");
        history.addView(historyText); LinearLayout.LayoutParams hp=lp(-1,-2); hp.topMargin=dp(14); root.addView(history,hp);

        editor = new EditText(this); editor.setGravity(Gravity.TOP|Gravity.START); editor.setTextSize(20); editor.setTextColor(Color.WHITE); editor.setHintTextColor(Color.LTGRAY);
        editor.setPadding(dp(14),dp(14),dp(14),dp(14)); editor.setMinLines(7); editor.setBackground(round(Color.rgb(60,60,60),dp(10)));
        LinearLayout.LayoutParams ep=lp(-1,dp(245)); ep.topMargin=dp(12); root.addView(editor,ep);

        Button add = button("+ Yeni Not", Color.rgb(0,130,45), Color.WHITE);
        LinearLayout.LayoutParams ap=lp(-1,dp(48)); ap.topMargin=dp(12); root.addView(add,ap);
        add.setOnClickListener(v->addTab());

        Button save = button("Kaydet", orange, Color.WHITE);
        LinearLayout.LayoutParams sp=lp(-1,dp(60)); sp.topMargin=dp(12); root.addView(save,sp);
        save.setOnClickListener(v->{ saveCurrentEditor(); Toast.makeText(this,"Not kaydedildi",Toast.LENGTH_SHORT).show(); refresh(); });
        Button delete = button("Bu Notu Sil", Color.rgb(70,35,30), Color.WHITE);
        LinearLayout.LayoutParams dp2=lp(-1,dp(48)); dp2.topMargin=dp(8); root.addView(delete,dp2);
        delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Not silinsin mi?").setMessage(activeTab+" silinecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sil",(d,w)->{ try { monthData().remove(activeTab); monthData().remove(activeTab+"__updated"); getSharedPreferences("agenda",MODE_PRIVATE).edit().putString("data",data.toString()).apply(); activeTab=firstTab(); refresh(); } catch(Exception ignored){} }).show());
        refresh();
    }

    private void refresh() {
        title.setText(months[month] + " " + year);
        monthRow.removeAllViews();
        for(int i=0;i<12;i++){ final int idx=i; Button b=button(months[i],i==month?orange:panel,Color.WHITE); monthRow.addView(b,new LinearLayout.LayoutParams(dp(105),dp(46))); b.setOnClickListener(v->{saveCurrentEditor();month=idx;refresh();}); }
        tabRow.removeAllViews();
        ArrayList<String> tabs = getTabs();
        if(!tabs.contains(activeTab)) activeTab=tabs.isEmpty()?"Not 1":tabs.get(0);
        for(String tab:tabs){ Button b=button(tab,tab.equals(activeTab)?orange:panel,Color.WHITE); tabRow.addView(b,new LinearLayout.LayoutParams(-2,dp(46))); b.setOnClickListener(v->{saveCurrentEditor();activeTab=tab;refresh();}); }
        editor.setText(readNote(activeTab));
        View historyBox = (View)((LinearLayout)root.getChildAt(3)).getChildAt(1);
        // History label is updated below by walking the history card.
        LinearLayout historyCard=(LinearLayout)root.getChildAt(3);
        TextView historyText=(TextView)historyCard.getChildAt(1);
        String updated=monthData().optString(activeTab+"__updated","");
        historyText.setText(updated.isEmpty()?"Henüz kayıt yok":"• "+updated);
    }

    private ArrayList<String> getTabs() {
        ArrayList<String> out=new ArrayList<>();
        JSONObject m=monthData();
        JSONArray arr=m.optJSONArray("__tabs");
        if(arr!=null) for(int i=0;i<arr.length();i++) out.add(arr.optString(i));
        if(out.isEmpty()) {
            for(String t:defaultTabs) out.add(t);
            try { JSONArray a=new JSONArray(); for(String t:out)a.put(t); m.put("__tabs",a); } catch(Exception ignored){}
        }
        return out;
    }
    private String firstTab(){ ArrayList<String> a=getTabs(); return a.isEmpty()?"Not 1":a.get(0); }
    private void saveCurrentEditor(){ if(editor==null)return; saveNote(activeTab,editor.getText().toString()); }
    private void showAllNotes() {
        saveCurrentEditor();
        class NoteItem {
            String dateKey, tab, body, updated;
            long sortTime;
            NoteItem(String d, String t, String b, String u, long st) {
                dateKey=d; tab=t; body=b; updated=u; sortTime=st;
            }
        }
        ArrayList<NoteItem> items = new ArrayList<>();
        Iterator<String> keys = data.keys();
        while(keys.hasNext()) {
            String dateKey = keys.next();
            JSONObject md = data.optJSONObject(dateKey);
            if(md == null || !dateKey.matches("\\d{4}-\\d{1,2}")) continue;
            Iterator<String> nt = md.keys();
            while(nt.hasNext()) {
                String tab = nt.next();
                if(tab.startsWith("__") || tab.endsWith("__updated")) continue;
                String body = md.optString(tab, "").trim();
                if(body.isEmpty()) continue;
                String updated = md.optString(tab + "__updated", "");
                long ts = 0;
                try { ts = new SimpleDateFormat("dd.MM.yyyy - HH:mm", new Locale("tr","TR")).parse(updated).getTime(); } catch(Exception ignored) {}
                items.add(new NoteItem(dateKey, tab, body, updated, ts));
            }
        }
        Collections.sort(items, (a,b) -> Long.compare(b.sortTime, a.sortTime));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12),dp(8),dp(12),dp(8));
        if(items.isEmpty()) {
            TextView empty = text("Henüz kaydedilmiş not yok.", 17, Color.WHITE, false);
            list.addView(empty);
        } else {
            for(NoteItem item : items) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12),dp(10),dp(12),dp(10));
                card.setBackground(round(Color.rgb(38,38,38), dp(10)));
                TextView head = text(item.tab + "  •  " + item.dateKey.replace("-", "."), 16, orange, true);
                TextView when = text(item.updated.isEmpty() ? "Tarih bilgisi yok" : "Son düzenleme: " + item.updated, 12, Color.LTGRAY, false);
                TextView body = text(item.body, 16, Color.WHITE, false);
                card.addView(head); card.addView(when);
                LinearLayout.LayoutParams bp = lp(-1,-2); bp.topMargin=dp(5); card.addView(body,bp);
                LinearLayout.LayoutParams cp = lp(-1,-2); cp.bottomMargin=dp(10); list.addView(card,cp);
                card.setOnClickListener(v -> {
                    try {
                        String[] parts = item.dateKey.split("-");
                        int yr = Integer.parseInt(parts[0]);
                        int mo = Integer.parseInt(parts[1]);
                        year = yr;
                        month = mo - 1;
                        activeTab = item.tab;
                        refresh();
                    } catch(Exception ignored) {}
                    Toast.makeText(this, "Not: " + item.tab + " (" + item.dateKey + ")", Toast.LENGTH_SHORT).show();
                });
            }
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        new AlertDialog.Builder(this)
            .setTitle("Tüm notlar • Tarihe göre")
            .setView(sv)
            .setPositiveButton("Kapat", null)
            .show();
    }

    private void addTab() {
        EditText input=new EditText(this); input.setSingleLine(true); input.setHint("Örn. İşlerim");
        new AlertDialog.Builder(this).setTitle("Yeni not bölümü").setView(input).setNegativeButton("İptal",null).setPositiveButton("Ekle",(d,w)->{
            String name=input.getText().toString().trim(); if(name.isEmpty()){Toast.makeText(this,"Bir ad yazmalısın",Toast.LENGTH_SHORT).show();return;}
            ArrayList<String> tabs=getTabs(); if(tabs.contains(name)){Toast.makeText(this,"Bu isim zaten var",Toast.LENGTH_SHORT).show();return;}
            tabs.add(name); JSONArray a=new JSONArray(); for(String t:tabs)a.put(t);
            try{monthData().put("__tabs",a);getSharedPreferences("agenda",MODE_PRIVATE).edit().putString("data",data.toString()).apply();}catch(Exception ignored){}
            saveCurrentEditor(); activeTab=name; refresh();
        }).show();
    }

    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t; }
    private Button button(String s,int color,int tc){ Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(15);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(color,dp(9)));b.setPadding(dp(8),0,dp(8),0);return b; }
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
