01NOTE - ÇEVRİMDIŞI ANDROID AJANDA

Bu proje önceki ajanda dosyalarından ayrı isimlerle hazırlanmıştır.
- GitHub'a yüklenecek kaynak ZIP adı: 01note_android_source.zip
- Android applicationId: com.example.note01
- Telefonda görünen uygulama adı: 01Note
- GitHub Actions workflow adı: Build 01Note APK
- APK artifact adı: 01Note-APK

Özellikler:
- İnternet izni istemez; kurulduktan sonra çevrimdışı çalışır.
- Notlar telefonun uygulama hafızasında saklanır.
- Aylar ve not bölümleri.
- Tüm Notlar ekranı: notları son düzenleme tarihine göre listeler.
- Alarm yok.

TELEFONDAN APK OLUŞTURMA:
1) GitHub'da yeni, ayrı bir depo oluşturun. Depo adı: 01note
2) Bu ZIP dosyasını yeni deponun köküne yükleyin ve Commit changes deyin.
3) Yeni dosya oluşturun: .github/workflows/build-01note.yml
4) Ayrı verilen build-01note.yml dosyasının içeriğini yapıştırın ve Commit changes deyin.
5) Actions sekmesine girip Build 01Note APK işlemini açın.
6) İşlem başarılı olunca Artifacts bölümünden 01Note-APK dosyasını indirin.
7) İndirilen ZIP içinden app-debug.apk dosyasını telefona kurun.

Bu yapılandırma yapay zekâ API token'ı istemez. GitHub Actions kullanımı GitHub'ın güncel ücretsiz kullanım koşullarına tabidir.
Notlar uygulamanın yerel hafızasında tutulur. Uygulamayı kaldırmak verileri silebilir; yedek alın.
